![](full_black.png)

## Пояснительная записка 

## к дипломному проекту

## на тему:

## "Предсказание тематических категорий для новостных публикаций по их содержанию"


Автор: Трофимов Павел

Группа: DSU-60

Ментор: Яблонева Тора

Презентация: [Дипломная работа.Презентация](https://docs.google.com/presentation/d/1VGzD3roFJqspsK0UnXWlqhX7CuykYW1e65I7m6W82uA/edit?usp=sharing)

Репозиторий: [Дипломная работа. Github](https://github.com/TrofimovPaul/NetologyThesis)

Датасеты: [Исходный датасет (800 000
строк)](https://www.kaggle.com/datasets/yutkin/corpus-of-russian-news-articles-from-lenta/data), [Обработанный датасет
(71070 строк)](https://www.kaggle.com/datasets/trofimovpaul/news-datasets-train-test)


<!-- for docx generation:
pandoc -f markdown -s 01title.md title.docx
--> 

[comment]: # (pandoc -f markdown -s 01title.md out/nto_out.docx
)

[comment]: <> (pandoc -f markdown -s 01title.md out/nto_out.docx
)
# Ссылки на источники

1. kaggle.com/code/kmkarakaya/multi-label-model-evaluation [Multi Label Model Evaluation]
1. wiki.cloudfactory.com/docs/mp-wiki/metrics/hamming-score [Hamming score]
1. habr.com/ru/articles/503420 [Лемматизируй это быстрее (PyMorphy2, PyMystem3 и немного магии)]
1. github.com/trent-b/iterative-stratification?tab=readme-ov-file [iterative-stratification]
1. github.com/catboost/tutorials/blob/master/classification/multilabel_classification_tutorial.ipynb [Multi Label Binary
   Classification with CatBoost]
1. huggingface.co [Портал с предобученными транформерами]
1. habr.com/ru/articles/680986 [Все, что нужно знать об ALBERT, RoBERTa и DistilBERT]
